Student name: Mitchell Eisenberg
Student number: 300065976
Course code: ITI1121
Lab section: B-4

This archive contains the 6 files of lab 7, that is, this file (README.txt),
plus Controller.java, Timer.java, View.java, GraphicalView.java, TextView.java.