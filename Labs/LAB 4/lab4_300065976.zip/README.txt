Student name: Mitchell Eisenberg
Student number: 300065976
Course code: ITI1121
Lab section: B-4

This archive contains the 6 files of the lab 4, that is, this file (README.txt),
plus the files Likeable.java, Post.java, TextPost.java, PhotoPost.java, NewsFeed.java.