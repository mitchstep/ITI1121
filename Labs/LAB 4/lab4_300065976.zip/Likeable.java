public interface Likeable {
    public abstract void like();
    public abstract int getLikes();
}
