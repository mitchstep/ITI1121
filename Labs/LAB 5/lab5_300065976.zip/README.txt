Student name: Mitchell Eisenberg
Student number: 300065976
Course code: ITI1121
Lab section: B-4

This archive contains the 8 files of the lab 5, that is, this file (README.txt),
plus the files AbstractSeries.java, Arithmetic.java, Book.java, BookComparator.java, Geometric.java, Library.java, and Series.java.