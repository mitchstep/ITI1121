Mitchell Eisenberg	300065976	ITI 1121-B
Justin Proulx 		300060172	ITI 1121-C

Assignment 4, Pastiche, is a plagrism checker which compares two text files and outputs the percent similarity of the two files.