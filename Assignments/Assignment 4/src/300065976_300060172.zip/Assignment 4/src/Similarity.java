public interface Similarity {
    public double score​(WordMap a, WordMap b);
}
