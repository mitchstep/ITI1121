Mitchell Eisenberg	300065976	ITI 1121-B
Justin Proulx 		300060172	ITI 1121-C

Assignment 3, the lights out game, includes two implementations the first of which finds all possible solutions for the given grid and the second inplementation creates a UI for it